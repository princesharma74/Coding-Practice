main_ex1.cpp is exercise 1. input is hard coded.
main_ex2.cpp is exercise 2. input is taken from a file named "input.txt"